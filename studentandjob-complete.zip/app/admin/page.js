'use client';

import { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabaseClient';
import AdminLogin from '@/components/admin/AdminLogin';
import Sidebar from '@/components/admin/Sidebar';
import Topbar from '@/components/admin/Topbar';
import WelcomeCard from '@/components/admin/WelcomeCard';
import StatCard from '@/components/admin/StatCard';
import SettingsForm from '@/components/admin/SettingsForm';
import PagesAdsManager from '@/components/admin/PagesAdsManager';
import TextThemeManager from '@/components/admin/TextThemeManager';
import ThemeSettingsManager from '@/components/admin/ThemeSettingsManager';
import SocialMediaForm from '@/components/admin/SocialMediaForm';
import ListManager from '@/components/admin/ListManager';
import MessagesManager from '@/components/admin/MessagesManager';
import ContactsManager from '@/components/admin/ContactsManager';
import PagesManager from '@/components/admin/PagesManager';
import JobsManager from '@/components/admin/JobsManager';
import WhatsAppServiceForm from '@/components/admin/WhatsAppServiceForm';
import DirectoryAdmin from '@/components/admin/DirectoryAdmin';
import StudyZoneManager from '@/components/admin/StudyZone/StudyZoneManager';
import StaffManager from '@/components/admin/Staff/StaffManager';
import {
  ImageIcon,
  BriefcaseIcon,
  BookIcon,
  SettingsIcon,
  ClipboardCheckIcon,
  AwardIcon,
  MailIcon,
  IdCardIcon,
  FileTextIcon,
  Share2Icon,
  GraduationCapIcon,
} from '@/components/admin/icons';

// Titles shown in the Topbar — one per menu item in the Sidebar, mirroring
// every page that exists on the public website.
const TAB_TITLES = {
  dashboard: 'Dashboard',
  settings: 'Site Settings',
  pages_ads: 'Pages & Ads',
  themesettings: 'Theme Settings',
  texttheme: 'Text Theme',
  social: 'Social Media',
  slides: 'Hero Slides',
  jobs: 'Jobs',
  whatsapp_service: 'WhatsApp Service',
  studyzone: 'Study Zone (Tests, Papers & Notes)',
  results: 'Results',
  scholarships: 'Scholarships',
  directory: 'Bahawalpur Business Directory',
  messages: 'Contact Messages',
  contacts: 'Contact Us',
  pages: 'Pages (About / Legal)',
  staff: 'Staff / Users',
};

export default function AdminDashboard() {
  const [session, setSession] = useState(undefined); // undefined = checking, null = logged out
  const [settings, setSettings] = useState(null);
  const [slides, setSlides] = useState([]);
  const [jobs, setJobs] = useState([]);
  const [notes, setNotes] = useState([]);
  const [results, setResults] = useState([]);
  const [scholarships, setScholarships] = useState([]);
  const [businesses, setBusinesses] = useState([]);
  const [dirCategories, setDirCategories] = useState([]);
  const [dirCities, setDirCities] = useState([]);
  const [dirAreas, setDirAreas] = useState([]);
  const [messages, setMessages] = useState([]);
  const [contacts, setContacts] = useState([]);
  const [pages, setPages] = useState([]);
  const [studyClasses, setStudyClasses] = useState([]);
  const [studySubjects, setStudySubjects] = useState([]);
  const [studyMaterials, setStudyMaterials] = useState([]);
  const [staff, setStaff] = useState([]);
  const [staffPermissions, setStaffPermissions] = useState([]);
  const [loadingData, setLoadingData] = useState(true);
  const userId = session?.user?.id || null;
  const [activeTab, setActiveTab] = useState('dashboard');
  const [sidebarOpen, setSidebarOpen] = useState(false);

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) =>
      setSession((prev) => (prev && data.session && prev.user?.id === data.session.user?.id ? prev : data.session))
    );
    // Supabase re-emits auth events (TOKEN_REFRESHED / SIGNED_IN) whenever the
    // browser tab regains focus. Keep the same session object when it is the
    // same user, otherwise the whole dashboard reloads and any half-filled
    // form (e.g. a new job) is wiped.
    const { data: listener } = supabase.auth.onAuthStateChange((_event, sess) =>
      setSession((prev) => (prev && sess && prev.user?.id === sess.user?.id ? prev : sess))
    );
    return () => listener.subscription.unsubscribe();
  }, []);

  // Fetch just enough site settings (name + logo) to brand the Login screen
  // itself, independent of the session check above — site_settings is
  // publicly readable, so this works before the admin is even logged in.
  // Skipped once logged in, since the full settings fetch below already
  // covers it (and stays fresher via the same query).
  useEffect(() => {
    if (userId) return;
    supabase
      .from('site_settings')
      .select('site_name, logo_url')
      .order('updated_at', { ascending: false, nullsFirst: false })
      .limit(1)
      .maybeSingle()
      .then(({ data }) => {
        if (data) setSettings((prev) => prev || data);
      });
  }, [userId]);

  useEffect(() => {
    if (!userId) return;
    (async () => {
      setLoadingData(true);
      const [{ data: s }, { data: sl }, { data: j }, { data: n }, { data: r }, { data: sc }, { data: m }, { data: c }, { data: p }, { data: sCls }, { data: sSub }, { data: sMat }, { data: stf }, { data: sp }, { data: biz }, { data: dCat }, { data: dCity }, { data: dArea }] =
        await Promise.all([
          supabase.from('site_settings').select('*').order('updated_at', { ascending: false, nullsFirst: false }).limit(1).maybeSingle(),
          supabase.from('hero_slides').select('*').order('display_order', { ascending: true }),
          supabase.from('jobs_table').select('*').order('created_at', { ascending: false }),
          supabase.from('students_data').select('*').order('created_at', { ascending: false }),
          supabase.from('results_table').select('*').order('created_at', { ascending: false }),
          supabase.from('scholarships_table').select('*').order('created_at', { ascending: false }),
          supabase.from('contact_messages').select('*').order('created_at', { ascending: false }),
          supabase.from('site_contacts').select('*').order('display_order', { ascending: true }),
          supabase.from('site_pages').select('*').order('slug', { ascending: true }),
          supabase.from('classes').select('*').order('display_order', { ascending: true }),
          supabase.from('subjects').select('*').order('subject_name', { ascending: true }),
          supabase.from('study_materials').select('*').order('created_at', { ascending: false }),
          supabase.from('staff_users').select('*').order('created_at', { ascending: false }),
          supabase.from('staff_permissions').select('*'),
          supabase.from('businesses_table').select('*').order('created_at', { ascending: false }),
          supabase.from('directory_categories').select('*').order('display_order', { ascending: true }),
          supabase.from('directory_cities').select('*').order('display_order', { ascending: true }),
          supabase.from('directory_areas').select('*').order('display_order', { ascending: true }),
        ]);
      setSettings(s);
      setSlides(sl || []);
      setJobs(j || []);
      setNotes(n || []);
      setResults(r || []);
      setScholarships(sc || []);
      setMessages(m || []);
      setContacts(c || []);
      setPages(p || []);
      setStudyClasses(sCls || []);
      setStudySubjects(sSub || []);
      setStudyMaterials(sMat || []);
      setStaff(stf || []);
      setStaffPermissions(sp || []);
      setBusinesses(biz || []);
      setDirCategories(dCat || []);
      setDirCities(dCity || []);
      setDirAreas(dArea || []);
      setLoadingData(false);
    })();
  }, [userId]);

  async function handleLogout() {
    await supabase.auth.signOut();
    setSession(null);
  }

  if (session === undefined) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-[#F0F4F3] text-amuted">Loading...</div>
    );
  }

  if (!session) {
    return <AdminLogin onLoggedIn={setSession} siteName={settings?.site_name} logoUrl={settings?.logo_url} />;
  }

  const unreadMessages = messages.filter((m) => !m.is_read).length;

  return (
    <div className="flex min-h-screen bg-[#F0F4F3]">
      <Sidebar
        activeTab={activeTab}
        onTabChange={setActiveTab}
        open={sidebarOpen}
        onClose={() => setSidebarOpen(false)}
        siteName={settings?.site_name}
        logoUrl={settings?.logo_url}
        onLogout={handleLogout}
        unreadMessages={unreadMessages}
      />

      <main className="flex min-h-screen w-full flex-1 flex-col md:ml-[240px] md:w-[calc(100%-240px)]">
        <Topbar title={TAB_TITLES[activeTab]} onMenuClick={() => setSidebarOpen(true)} />

        <div className="w-full flex-1 p-4 sm:p-6">
          {loadingData ? (
            <p className="py-10 text-center text-sm text-amuted">Loading content...</p>
          ) : (
            <>
              {activeTab === 'dashboard' && (
                <div className="flex flex-col gap-5">
                  <WelcomeCard siteName={settings?.site_name} subHeading={settings?.sub_heading} />
                  <div className="grid grid-cols-2 gap-3.5 sm:grid-cols-4">
                    <StatCard icon={ImageIcon} value={slides.length} label="Hero Slides" color="gold" onClick={() => setActiveTab('slides')} />
                    <StatCard icon={BriefcaseIcon} value={jobs.length} label="Jobs Posted" color="teal" onClick={() => setActiveTab('jobs')} />
                    <StatCard icon={BookIcon} value={notes.length} label="Study Notes" color="coral" onClick={() => setActiveTab('studyzone')} />
                    <StatCard
                      icon={GraduationCapIcon}
                      value={studyClasses.length}
                      label="Study Zone Classes"
                      color="green"
                      onClick={() => setActiveTab('studyzone')}
                    />
                    <StatCard icon={ClipboardCheckIcon} value={results.length} label="Results" color="green" onClick={() => setActiveTab('results')} />
                    <StatCard icon={AwardIcon} value={scholarships.length} label="Scholarships" color="purple" onClick={() => setActiveTab('scholarships')} />
                    <StatCard icon={BriefcaseIcon} value={businesses.length} label="Directory Businesses" color="green" onClick={() => setActiveTab('directory')} />
                    <StatCard
                      icon={MailIcon}
                      value={unreadMessages > 0 ? `${messages.length} (${unreadMessages} new)` : messages.length}
                      label="Contact Messages"
                      color="blue"
                      onClick={() => setActiveTab('messages')}
                    />
                    <StatCard icon={IdCardIcon} value={contacts.length} label="Contact Us Entries" color="coral" onClick={() => setActiveTab('contacts')} />
                    <StatCard icon={FileTextIcon} value={pages.length} label="Static Pages" color="teal" onClick={() => setActiveTab('pages')} />
                    <StatCard icon={SettingsIcon} value={settings ? 'Set' : '—'} label="Site Settings" color="gold" onClick={() => setActiveTab('settings')} />
                    <StatCard
                      icon={Share2Icon}
                      value={
                        ['facebook_url', 'whatsapp_channel_url', 'instagram_url', 'youtube_url', 'tiktok_url', 'twitter_url', 'linkedin_url'].filter(
                          (f) => settings?.[f]
                        ).length
                      }
                      label="Social Links Set"
                      color="teal"
                      onClick={() => setActiveTab('social')}
                    />
                  </div>
                </div>
              )}

              {activeTab === 'settings' && <SettingsForm settings={settings} />}

              {activeTab === 'pages_ads' && <PagesAdsManager settings={settings} />}

              {activeTab === 'themesettings' && <ThemeSettingsManager />}

              {activeTab === 'texttheme' && <TextThemeManager settings={settings} />}

              {activeTab === 'social' && <SocialMediaForm settings={settings} />}

              {activeTab === 'slides' && (
                <ListManager
                  title="Hero Slides"
                  description="Slides shown on the home page banner, in display order. Each slide is either an image OR a YouTube video — fill in just one of the two."
                  icon={ImageIcon}
                  table="hero_slides"
                  initialRows={slides}
                  fields={[
                    { name: 'title', label: 'Title', required: true },
                    {
                      name: 'image_url',
                      label: 'Slide Image',
                      type: 'image',
                      imageFolder: 'hero',
                      requireGroup: 'media',
                    },
                    {
                      name: 'video_url',
                      label: 'YouTube Video URL',
                      placeholder: 'https://www.youtube.com/watch?v=...',
                      requireGroup: 'media',
                    },
                    { name: 'link_url', label: 'Link URL (optional, image slides only)', placeholder: 'https://...' },
                    { name: 'display_order', label: 'Display Order', type: 'number', placeholder: '1' },
                  ]}
                  renderRow={(row) => (
                    <div>
                      <p className="font-semibold text-aink">
                        {row.title} {row.video_url && <span className="ml-1 text-xs font-normal text-amuted">(YouTube video)</span>}
                      </p>
                      <p className="text-xs text-amuted">Order: {row.display_order}</p>
                    </div>
                  )}
                />
              )}

              {activeTab === 'jobs' && <JobsManager initialJobs={jobs} settings={settings} />}

              {activeTab === 'whatsapp_service' && <WhatsAppServiceForm settings={settings} />}

              {activeTab === 'studyzone' && (
                <div className="flex flex-col gap-6">
                  <StudyZoneManager initialClasses={studyClasses} initialSubjects={studySubjects} initialMaterials={studyMaterials} />

                  <ListManager
                    title="Notes"
                    description="PDFs and notes shown in the Study Zone → Notes section."
                    icon={BookIcon}
                    table="students_data"
                    initialRows={notes}
                    fields={[
                      { name: 'title', label: 'Title', required: true },
                      { name: 'category', label: 'Category', placeholder: 'e.g. Guess Paper, Notes' },
                      { name: 'file_url', label: 'Upload PDF', type: 'file', fileFolder: 'notes', required: true },
                    ]}
                    renderRow={(row) => (
                      <div>
                        <p className="font-semibold text-aink">{row.title}</p>
                        <p className="text-xs text-amuted">{row.category}</p>
                      </div>
                    )}
                  />
                </div>
              )}

              {activeTab === 'results' && (
                <ListManager
                  title="Results"
                  description="Exam / test results shown on the public Results page."
                  icon={ClipboardCheckIcon}
                  table="results_table"
                  initialRows={results}
                  fields={[
                    { name: 'title', label: 'Result Title', required: true, placeholder: 'e.g. FA/FSc Annual Result 2026' },
                    { name: 'board_or_department', label: 'Board / Department' },
                    { name: 'result_date', label: 'Announced Date', type: 'date' },
                    { name: 'result_link', label: 'Result Link', placeholder: 'https://...' },
                  ]}
                  renderRow={(row) => (
                    <div>
                      <p className="font-semibold text-aink">{row.title}</p>
                      <p className="text-xs text-amuted">
                        {row.board_or_department} {row.result_date && `· Announced: ${row.result_date}`}
                      </p>
                    </div>
                  )}
                />
              )}

              {activeTab === 'scholarships' && (
                <ListManager
                  title="Scholarships"
                  description="Scholarship opportunities shown on the public Scholarships page."
                  icon={AwardIcon}
                  table="scholarships_table"
                  initialRows={scholarships}
                  fields={[
                    { name: 'title', label: 'Scholarship Title', required: true },
                    { name: 'provider', label: 'Provider / Organization' },
                    { name: 'deadline', label: 'Application Deadline', type: 'date' },
                    { name: 'apply_link', label: 'Apply Link', placeholder: 'https://...' },
                  ]}
                  renderRow={(row) => (
                    <div>
                      <p className="font-semibold text-aink">{row.title}</p>
                      <p className="text-xs text-amuted">
                        {row.provider} {row.deadline && `· Deadline: ${row.deadline}`}
                      </p>
                    </div>
                  )}
                />
              )}

              {activeTab === 'directory' && (
                <DirectoryAdmin
                  initialBusinesses={businesses}
                  initialCategories={dirCategories}
                  initialCities={dirCities}
                  initialAreas={dirAreas}
                />
              )}

              {activeTab === 'messages' && <MessagesManager initialRows={messages} />}

              {activeTab === 'contacts' && <ContactsManager initialRows={contacts} />}

              {activeTab === 'pages' && <PagesManager initialRows={pages} />}

              {activeTab === 'staff' && <StaffManager initialStaff={staff} initialPermissions={staffPermissions} />}
            </>
          )}
        </div>
      </main>
    </div>
  );
}
