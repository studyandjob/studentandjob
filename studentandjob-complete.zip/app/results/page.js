import Header from '@/components/Header';
import NewsTicker from '@/components/NewsTicker';
import Footer from '@/components/Footer';
import PageBanner from '@/components/PageBanner';
import ResultCard from '@/components/ResultCard';
import { VerifiedBadgeIcon3D } from '@/components/Icons3D';
import { getSiteSettings, getResults } from '@/lib/data';

export const dynamic = 'force-dynamic';

export async function generateMetadata() {
  const settings = await getSiteSettings();
  return { title: `Results — ${settings.site_name || 'Education & Job Portal'}` };
}

export default async function ResultsPage() {
  const [settings, results] = await Promise.all([getSiteSettings(), getResults()]);

  return (
    <>
      <NewsTicker text={settings.show_news_ticker === false ? '' : settings.scrolling_news} />
      <Header siteName={settings.site_name} logoUrl={settings.logo_url} />

      <main className="flex-1 bg-surface">
        <PageBanner
          title="Results"
          subtitle="Latest exam and test results — check your result online."
          icon={<VerifiedBadgeIcon3D className="h-9 w-9" />}
        />

        <div className="mx-auto max-w-7xl px-4 py-10 md:px-6 md:py-14">
          <p className="mb-6 text-sm text-gray-500">
            {results.length} result{results.length === 1 ? '' : 's'} announced
          </p>

          {results.length === 0 ? (
            <div className="rounded-2xl bg-surface p-10 text-center border border-line shadow-card">
              <p className="text-sm text-gray-500">No results announced yet. Check back soon.</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3">
              {results.map((r) => (
                <ResultCard key={r.id} result={r} />
              ))}
            </div>
          )}
        </div>
      </main>

      <Footer siteName={settings.site_name} settings={settings} />
    </>
  );
}
