'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';
import Image from 'next/image';
import SearchBar from './SearchBar';
import { BriefcaseIcon3D, GraduationCapIcon3D, ShieldCheckIcon3D } from './Icons3D';

// Admin-entered main/sub headings (site_settings.main_heading / sub_heading)
// can be English, Urdu, or a mix. Detect Arabic/Urdu script so the text
// still gets the right font/direction even inside this new hero layout.
const URDU_SCRIPT_RE = /[\u0600-\u06FF\u0750-\u077F\uFB50-\uFDFF\uFE70-\uFEFF]/;
function isUrduText(text) {
  return typeof text === 'string' && URDU_SCRIPT_RE.test(text);
}

// Splits a heading like "Find Jobs. Build Skills. Shape Your Future." into
// a plain lead part and a highlighted last sentence, the way the reference
// design does (final sentence in the accent color). No hardcoded fallback
// text here — if the admin hasn't set a heading yet, the caller simply
// doesn't render this at all (see Hero() below).
function splitHeading(heading) {
  const text = heading.trim();
  const parts = text.split(/(?<=[.!?])\s+/).filter(Boolean);
  if (parts.length < 2) return { lead: text, highlight: '' };
  return { lead: parts.slice(0, -1).join(' '), highlight: parts[parts.length - 1] };
}

export default function Hero({ mainHeading, subHeading, illustrationUrl, slides = [], openJobsCount = 0 }) {
  const hasHeading = Boolean(mainHeading?.trim());
  const hasSubHeading = Boolean(subHeading?.trim());
  const { lead, highlight } = hasHeading ? splitHeading(mainHeading) : { lead: '', highlight: '' };
  const rtl = isUrduText(mainHeading);

  return (
    <section className="relative overflow-hidden bg-gradient-to-b from-brand-50/60 via-white to-white">
      {/* Very subtle dot texture for depth — not a decorative photo, just
          a low-opacity pattern so the hero doesn't read as a flat block.
          Kept faint on purpose (see brief: avoid excessive gradients). */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute inset-0 opacity-[0.04]"
        style={{
          backgroundImage: 'radial-gradient(circle at 1.5px 1.5px, currentColor 1.5px, transparent 0)',
          backgroundSize: '26px 26px',
          color: 'rgb(var(--brand-600))',
        }}
      />

      <div className="relative mx-auto grid max-w-7xl grid-cols-1 items-center gap-10 px-4 py-12 md:px-6 md:py-16 lg:grid-cols-2 lg:gap-12">
        {/* Copy column */}
        <div className="text-center lg:text-left">
          <div className="flex flex-wrap items-center justify-center gap-2 lg:justify-start">
            <span className="inline-flex items-center gap-1.5 rounded-full bg-brand-50 px-3.5 py-1.5 text-xs font-semibold text-brand-700 ring-1 ring-inset ring-brand-100">
              Your One-Stop Platform for Jobs &amp; Study
            </span>

            {/* Live, real open-jobs count (allOpenJobs.length from the
                homepage query) — not a static marketing claim. Hidden
                entirely when there are no open jobs, same "say nothing
                rather than a weak number" rule as StatsStrip. */}
            {openJobsCount > 0 && (
              <span className="inline-flex items-center gap-1.5 rounded-full bg-emerald-50 px-3.5 py-1.5 text-xs font-semibold text-emerald-700 ring-1 ring-inset ring-emerald-100">
                <span className="relative flex h-1.5 w-1.5">
                  <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-emerald-400 opacity-75" />
                  <span className="relative inline-flex h-1.5 w-1.5 rounded-full bg-emerald-500" />
                </span>
                {openJobsCount}+ Jobs Open Right Now
              </span>
            )}
          </div>

          {/* Main heading (site_settings.main_heading) — nothing shown
              here until the admin actually sets it in Admin → Website
              Settings, so this never displays placeholder marketing copy. */}
          {hasHeading && (
            <h1
              className="mt-5 text-4xl font-bold leading-[1.1] tracking-tight text-gray-900 sm:text-5xl lg:text-[3.25rem]"
              dir={rtl ? 'rtl' : undefined}
              lang={rtl ? 'ur' : undefined}
            >
              <span className={rtl ? 'font-urdu' : 'font-serif'}>
                {lead}
                {highlight && (
                  <>
                    {' '}
                    <span className="text-accent-600">{highlight}</span>
                  </>
                )}
              </span>
            </h1>
          )}

          {/* Sub-heading (site_settings.sub_heading) — same rule: only
              rendered once the admin has actually entered one. */}
          {hasSubHeading && (
            <p className="mx-auto mt-4 max-w-xl text-base leading-relaxed text-gray-600 lg:mx-0 lg:text-lg">
              {subHeading}
            </p>
          )}

          <div className="mt-7 flex flex-wrap items-center justify-center gap-3 lg:justify-start">
            <Link
              href="/jobs"
              className="inline-flex items-center gap-2 rounded-lg bg-brand-600 px-5 py-3.5 text-sm font-semibold text-white shadow-sm shadow-brand-600/20 transition hover:bg-brand-700 hover:shadow-md active:scale-[0.98]"
            >
              <BriefcaseIcon3D className="h-4 w-4" />
              Explore Latest Jobs
            </Link>
            <Link
              href="/study-zone"
              className="inline-flex items-center gap-2 rounded-lg border-2 border-brand-600 bg-surface px-5 py-3.5 text-sm font-semibold text-brand-700 transition hover:bg-brand-50 hover:shadow-sm active:scale-[0.98]"
            >
              <GraduationCapIcon3D className="h-4 w-4" />
              Explore Study Resources
            </Link>
          </div>

          <div className="mx-auto mt-7 max-w-lg lg:mx-0">
            <SearchBar />
          </div>
        </div>

        {/* Visual column — an admin-uploaded illustration when one exists,
            otherwise a built-in abstract composition (icons + shapes, no
            stock photo) so the hero always has a balanced second column
            instead of collapsing to plain centered text. */}
        {slides.length > 0 ? (
          <HeroImageCarousel slides={slides} />
        ) : illustrationUrl ? (
          <div className="relative mx-auto w-full max-w-sm lg:max-w-md">
            <div className="relative aspect-square w-full">
              <Image
                src={illustrationUrl}
                alt=""
                fill
                sizes="(min-width: 1024px) 448px, 384px"
                priority
                className="object-contain"
              />
            </div>
          </div>
        ) : (
          <DefaultHeroVisual />
        )}
      </div>
    </section>
  );
}

// Auto-rotating image/video carousel for the hero's visual column, fed by
// the admin's "Hero Slides" list (Admin → Hero Slides — title, image OR a
// YouTube video URL, optional link, display order). Slides advance on a
// timer and via dots, same translate-the-track pattern used by the job
// spotlight slider elsewhere on the home page.
const SLIDE_INTERVAL_MS = 5000;

// Pulls the 11-character video ID out of any common YouTube URL shape
// (watch?v=, youtu.be/, /embed/, /shorts/) so admins can paste whatever
// link they copied from the address bar or the Share button, instead of
// having to hand-craft an embed URL. Returns null for anything that isn't
// a recognizable YouTube link, so callers can fall back gracefully.
function getYouTubeVideoId(url) {
  if (typeof url !== 'string' || !url.trim()) return null;
  const match = url.match(
    /(?:youtube\.com\/(?:watch\?v=|embed\/|shorts\/)|youtu\.be\/)([a-zA-Z0-9_-]{11})/
  );
  return match ? match[1] : null;
}

function HeroImageCarousel({ slides }) {
  const [active, setActive] = useState(0);

  // Is the currently-shown slide a YouTube video? If so, the timer below
  // is paused entirely — auto-advancing mid-video used to cut it off after
  // 5 seconds. Image slides keep auto-rotating as before; video slides
  // only move on when the person clicks a dot (or the video ends, handled
  // by the iframe's own loop=1 param replaying it instead of advancing).
  const activeIsVideo = Boolean(getYouTubeVideoId(slides[active]?.video_url));

  useEffect(() => {
    if (slides.length < 2 || activeIsVideo) return;
    const timer = setInterval(() => {
      setActive((prev) => (prev + 1) % slides.length);
    }, SLIDE_INTERVAL_MS);
    return () => clearInterval(timer);
  }, [slides.length, active, activeIsVideo]);

  useEffect(() => {
    if (active >= slides.length) setActive(0);
  }, [slides.length, active]);

  return (
    <div className="relative mx-auto w-full max-w-sm lg:max-w-md">
      <div className="relative aspect-square w-full overflow-hidden rounded-[1.5rem]">
        <div
          className="flex h-full transition-transform duration-700 ease-in-out"
          style={{ transform: `translateX(-${active * 100}%)` }}
        >
          {slides.map((slide, i) => {
            const videoId = getYouTubeVideoId(slide.video_url);

            // Video slide: only the currently-active slide actually loads
            // the YouTube iframe (autoplaying, muted, looped so it behaves
            // like a silent hero banner). Inactive video slides show the
            // video's thumbnail instead — keeps the slide's width in the
            // sliding track without every video in the list loading and
            // playing at once in the background.
            if (videoId) {
              return (
                <div key={slide.id} className="relative h-full w-full flex-shrink-0 bg-black">
                  {i === active ? (
                    <iframe
                      className="absolute inset-0 h-full w-full"
                      src={`https://www.youtube.com/embed/${videoId}?autoplay=1&mute=1&loop=1&playlist=${videoId}&controls=1&playsinline=1&rel=0`}
                      title={slide.title || 'Hero video slide'}
                      allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                      allowFullScreen
                    />
                  ) : (
                    <Image
                      src={`https://img.youtube.com/vi/${videoId}/hqdefault.jpg`}
                      alt={slide.title || ''}
                      fill
                      sizes="(min-width: 1024px) 448px, 384px"
                      className="object-cover"
                      unoptimized
                    />
                  )}
                </div>
              );
            }

            // No usable video AND no image (e.g. an unrecognized YouTube
            // link with no image fallback) — skip this slide entirely
            // rather than letting next/image crash on an empty src.
            const hasImage = typeof slide.image_url === 'string' && slide.image_url.trim() !== '';
            if (!hasImage) return null;

            const isExternal = /^https?:\/\//.test(slide.link_url || '');
            const image = (
              <Image
                src={slide.image_url}
                alt={slide.title || ''}
                fill
                sizes="(min-width: 1024px) 448px, 384px"
                priority={i === 0}
                className="object-contain"
              />
            );
            return (
              <div key={slide.id} className="relative h-full w-full flex-shrink-0">
                {slide.link_url ? (
                  <Link
                    href={slide.link_url}
                    target={isExternal ? '_blank' : undefined}
                    rel={isExternal ? 'noopener noreferrer' : undefined}
                    className="relative block h-full w-full"
                    aria-label={slide.title || 'Hero slide'}
                  >
                    {image}
                  </Link>
                ) : (
                  image
                )}
              </div>
            );
          })}
        </div>
      </div>

      {slides.length > 1 && (
        <div className="mt-4 flex justify-center gap-2">
          {slides.map((slide, i) => (
            <button
              key={slide.id}
              onClick={() => setActive(i)}
              aria-label={`Go to slide ${i + 1}`}
              className={`h-2 rounded-full transition-all ${i === active ? 'w-6 bg-brand-600' : 'w-2 bg-brand-200'}`}
            />
          ))}
        </div>
      )}
    </div>
  );
}

// Built-in fallback visual for when the admin hasn't uploaded a hero
// illustration yet. Purely abstract (soft gradient blobs + the site's own
// icon set) — no stock photography or depiction of real people, so it
// never risks looking like a fabricated "testimonial" photo.
function DefaultHeroVisual() {
  return (
    <div className="relative mx-auto hidden aspect-square w-full max-w-md items-center justify-center lg:flex">
      <div className="absolute inset-0 rounded-[2.5rem] bg-gradient-to-br from-brand-50 via-white to-accent-50" />
      <div className="absolute inset-6 rounded-[2rem] border border-brand-100/70" />

      {/* Center badge — no overlaid category stickers, just the clean
          abstract composition. */}
      <div className="relative z-10 flex h-28 w-28 items-center justify-center rounded-full bg-surface shadow-xl shadow-brand-900/10 ring-1 ring-black/5">
        <ShieldCheckIcon3D className="h-12 w-12" />
      </div>
    </div>
  );
}

