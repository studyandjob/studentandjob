import { BriefcaseIcon3D, NotesBookIcon3D, GraduationCapIcon3D, VerifiedBadgeIcon3D } from './Icons3D';

function formatCount(n) {
  if (n >= 1000) return `${(n / 1000).toFixed(n % 1000 === 0 ? 0 : 1)}k+`;
  return n > 0 ? `${n}+` : '0';
}

export default function StatsStrip({ stats }) {
  const allItems = [
    { label: 'Jobs Posted', value: stats.jobs, Icon: BriefcaseIcon3D },
    { label: 'Notes & Papers', value: stats.notes, Icon: NotesBookIcon3D },
    { label: 'Scholarships Listed', value: stats.scholarships, Icon: GraduationCapIcon3D },
    { label: 'Results Announced', value: stats.results, Icon: VerifiedBadgeIcon3D },
  ];

  // Don't show a category that would read "0 ..." or a tiny, weak-looking
  // count like "1+"/"2+" — a growing site looks more professional saying
  // nothing than saying a small number. (Admin → Website Settings can also
  // set a starting "boost" number per category so real, honest totals
  // don't look sparse once there's meaningful content.)
  const MIN_DISPLAY_COUNT = 5;
  const items = allItems.filter((item) => item.value >= MIN_DISPLAY_COUNT);
  if (items.length === 0) return null;

  // Grid columns adapt to how many stats actually have data, so 2 or 3
  // live categories don't leave an awkward empty slot on desktop.
  const colsClass =
    items.length === 1
      ? 'grid-cols-1'
      : items.length === 2
      ? 'grid-cols-2'
      : items.length === 3
      ? 'grid-cols-2 sm:grid-cols-3'
      : 'grid-cols-2 sm:grid-cols-4';

  return (
    <div className="border-y border-line bg-gray-50/60">
      <div className={`mx-auto grid max-w-7xl ${colsClass} gap-6 px-4 py-10 md:gap-8 md:px-6 md:py-14`}>
        {items.map(({ label, value, Icon }) => (
          <div key={label} className="flex flex-col items-center gap-2.5 text-center">
            <span className="relative flex h-16 w-16 items-center justify-center rounded-2xl bg-gradient-to-br from-brand-100 to-brand-50">
              <span className="absolute inset-2 rounded-full bg-white/60 blur-md" aria-hidden="true" />
              <Icon className="relative h-10 w-10" />
            </span>
            <span className="text-2xl font-bold text-brand-700 md:text-3xl">{formatCount(value)}</span>
            <span className="text-xs font-medium text-gray-500 md:text-sm">{label}</span>
          </div>
        ))}
      </div>
    </div>
  );
}
