'use client';

import { useRef, useState } from 'react';
import { supabase } from '@/lib/supabaseClient';
import AdminCard from './AdminCard';
import RichContent from '../RichContent';
import { FileTextIcon, SaveIcon } from './icons';

const inputClass =
  'w-full rounded-[10px] border border-aline bg-[#FCFAF6] px-3.5 py-3 text-[0.93rem] text-aink outline-none transition focus:border-atl2 focus:ring-[3px] focus:ring-atl2/10';
const labelClass = 'mb-1.5 block text-[0.85rem] font-semibold text-aink';

const PAGE_LINKS = {
  'about-us': '/about-us',
  'privacy-policy': '/privacy-policy',
  disclaimer: '/disclaimer',
  'terms-and-conditions': '/terms-and-conditions',
};

// Toolbar buttons write the same plain-text conventions RichContent.jsx
// reads on the public site — admin never touches HTML, just clicks a
// button (or types the shortcut directly) and the live Preview tab
// shows exactly how it'll look before Save.
const TOOLBAR_BUTTONS = [
  { type: 'h2', label: 'H2' },
  { type: 'h3', label: 'H3' },
  { type: 'bullet', label: '• List' },
  { type: 'bold', label: 'B' },
];

function applyFormat(textareaRef, type, setContent) {
  const el = textareaRef.current;
  if (!el) return;

  const { selectionStart: start, selectionEnd: end, value } = el;
  const selected = value.slice(start, end);
  let insertText = '';

  if (type === 'h2' || type === 'h3') {
    const prefix = type === 'h2' ? '## ' : '### ';
    const body = selected || 'Heading text';
    const needsLeadingBreak = start > 0 && value[start - 1] !== '\n';
    insertText = `${needsLeadingBreak ? '\n' : ''}${prefix}${body}\n`;
  } else if (type === 'bullet') {
    const body = selected || 'List item';
    const lines = body.split('\n').map((l) => (l.trim().startsWith('- ') ? l : `- ${l}`));
    const needsLeadingBreak = start > 0 && value[start - 1] !== '\n';
    insertText = `${needsLeadingBreak ? '\n' : ''}${lines.join('\n')}\n`;
  } else if (type === 'bold') {
    insertText = `**${selected || 'bold text'}**`;
  }

  const newValue = value.slice(0, start) + insertText + value.slice(end);
  setContent(newValue);

  // Textarea is controlled by React state; wait for the re-render before
  // restoring focus and moving the caret to just after what was inserted.
  requestAnimationFrame(() => {
    el.focus();
    const pos = start + insertText.length;
    el.setSelectionRange(pos, pos);
  });
}

function PageEditor({ page }) {
  const [form, setForm] = useState({ title: page.title || '', content: page.content || '' });
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState('');
  const [tab, setTab] = useState('write'); // 'write' | 'preview'
  const textareaRef = useRef(null);

  function setContent(content) {
    setForm((f) => ({ ...f, content }));
  }

  async function handleSave(e) {
    e.preventDefault();
    setSaving(true);
    setMessage('');

    // .select() confirms the row was actually written — see notes elsewhere
    // in this project on why this check matters (silent RLS-blocked saves).
    const { data, error } = await supabase
      .from('site_pages')
      .update({ title: form.title, content: form.content, updated_at: new Date().toISOString() })
      .eq('id', page.id)
      .select();

    setSaving(false);
    if (error) {
      setMessage(`Error: ${error.message}`);
      return;
    }
    if (!data || data.length === 0) {
      setMessage('Error: Save did not go through — your admin session may have expired. Please log out and back in, then try again.');
      return;
    }
    setMessage('Saved successfully.');
  }

  return (
    <details className="group rounded-xl border border-aline bg-white open:shadow-sm" open={page._defaultOpen}>
      <summary className="flex cursor-pointer list-none items-center justify-between gap-3 px-4 py-3.5">
        <div className="min-w-0">
          <p className="font-semibold text-aink">{form.title || page.title}</p>
          <a
            href={PAGE_LINKS[page.slug] || '#'}
            target="_blank"
            rel="noopener noreferrer"
            className="text-xs text-atl2 hover:underline"
          >
            {PAGE_LINKS[page.slug] || `/${page.slug}`} ↗
          </a>
        </div>
        <span className="flex-shrink-0 text-xs font-semibold text-amuted transition group-open:rotate-180">▾</span>
      </summary>

      <form onSubmit={handleSave} className="flex flex-col gap-3.5 border-t border-aline p-4">
        <label className="block">
          <span className={labelClass}>Page Title</span>
          <input value={form.title} onChange={(e) => setForm((f) => ({ ...f, title: e.target.value }))} className={inputClass} />
        </label>

        <div>
          <div className="mb-1.5 flex items-center justify-between">
            <span className={labelClass + ' mb-0'}>Content</span>
            <div className="flex overflow-hidden rounded-lg border border-aline text-xs font-semibold">
              <button
                type="button"
                onClick={() => setTab('write')}
                className={`px-3 py-1.5 transition ${tab === 'write' ? 'bg-atl text-white' : 'bg-white text-amuted hover:text-aink'}`}
              >
                Write
              </button>
              <button
                type="button"
                onClick={() => setTab('preview')}
                className={`px-3 py-1.5 transition ${tab === 'preview' ? 'bg-atl text-white' : 'bg-white text-amuted hover:text-aink'}`}
              >
                Preview
              </button>
            </div>
          </div>

          {tab === 'write' ? (
            <>
              <div className="mb-2 flex flex-wrap gap-1.5">
                {TOOLBAR_BUTTONS.map((btn) => (
                  <button
                    key={btn.type}
                    type="button"
                    onClick={() => applyFormat(textareaRef, btn.type, setContent)}
                    className="rounded-md border border-aline bg-[#FCFAF6] px-2.5 py-1 text-xs font-bold text-aink transition hover:border-atl2 hover:text-atl2"
                  >
                    {btn.label}
                  </button>
                ))}
              </div>
              <textarea
                ref={textareaRef}
                value={form.content}
                onChange={(e) => setContent(e.target.value)}
                rows={10}
                placeholder="Write the page content here. Use the buttons above, or type directly: ## for a heading, ### for a sub-heading, a line starting with - for a bullet point, and a blank line between paragraphs."
                className={inputClass}
              />
              <p className="mt-1.5 text-xs text-amuted">
                <code className="rounded bg-gray-100 px-1">## Heading</code> ·{' '}
                <code className="rounded bg-gray-100 px-1">### Sub-heading</code> ·{' '}
                <code className="rounded bg-gray-100 px-1">- bullet point</code> ·{' '}
                <code className="rounded bg-gray-100 px-1">**bold**</code> · blank line = new paragraph.
              </p>
            </>
          ) : (
            <div className="max-h-[26rem] overflow-y-auto rounded-[10px] border border-aline bg-[#FCFAF6] p-4">
              {form.content.trim() ? (
                <RichContent text={form.content} />
              ) : (
                <p className="text-sm text-amuted">Nothing to preview yet — switch to Write and add some content.</p>
              )}
            </div>
          )}
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <button
            type="submit"
            disabled={saving}
            className="inline-flex items-center gap-2 rounded-full px-5 py-2.5 text-sm font-semibold text-white shadow-[0_6px_18px_-6px_rgba(30,132,73,0.5)] transition hover:-translate-y-0.5 disabled:opacity-60"
            style={{ background: 'linear-gradient(135deg, #1E8449, #2E5AAC)' }}
          >
            <SaveIcon className="h-4 w-4" />
            {saving ? 'Saving...' : 'Save Page'}
          </button>
          {message && (
            <span className={`text-sm ${message.startsWith('Error') ? 'text-red-600' : 'text-brand-600'}`}>
              {message}
            </span>
          )}
        </div>
      </form>
    </details>
  );
}

// Editor for the fixed set of static/legal pages (About Us, Privacy Policy,
// Disclaimer, Terms & Conditions). Rows are seeded by the SQL schema, so
// there's no add/delete here — just edit-and-save per page. Content can
// use headings, bullet points and paragraphs (see RichContent.jsx) so
// long pages stay readable instead of one solid block of text — still
// fully controlled from here, nothing to touch outside this dashboard.
export default function PagesManager({ initialRows = [] }) {
  return (
    <AdminCard
      title="Pages (About / Legal)"
      description="Edit the content shown on About Us, Privacy Policy, Disclaimer and Terms & Conditions. Use the toolbar for headings and bullet points, and Preview to check the layout before saving."
      icon={FileTextIcon}
    >
      {initialRows.length === 0 ? (
        <p className="py-6 text-center text-sm text-amuted">
          No pages found. Run the latest sql/schema.sql in Supabase to seed them.
        </p>
      ) : (
        <div className="flex flex-col gap-3">
          {initialRows.map((page, i) => (
            <PageEditor key={page.id} page={{ ...page, _defaultOpen: i === 0 }} />
          ))}
        </div>
      )}
    </AdminCard>
  );
}
