import Header from '@/components/Header';
import NewsTicker from '@/components/NewsTicker';
import Footer from '@/components/Footer';
import PageBanner from '@/components/PageBanner';
import RichContent from '@/components/RichContent';
import { getSiteSettings, getPage } from '@/lib/data';

// Shared renderer for the editable static/legal pages (About Us, Privacy
// Policy, Disclaimer, Terms & Conditions). Content is stored in the
// `site_pages` table and edited from the Admin Dashboard → Pages tab.
export default async function StaticPageContent({ slug, fallbackTitle }) {
  const [settings, page] = await Promise.all([getSiteSettings(), getPage(slug)]);
  const title = page?.title || fallbackTitle;
  const content = page?.content || '';

  return (
    <>
      <NewsTicker text={settings.show_news_ticker === false ? '' : settings.scrolling_news} />
      <Header siteName={settings.site_name} logoUrl={settings.logo_url} />

      <main className="flex-1 bg-surface">
        <PageBanner title={title} />

        <div className="mx-auto max-w-3xl px-4 py-10 md:px-6 md:py-14">
          <div className="rounded-2xl bg-surface p-6 border border-line shadow-card md:p-10">
            {content ? (
              <RichContent text={content} />
            ) : (
              <p className="text-sm text-gray-500">This page has no content yet.</p>
            )}
          </div>
        </div>
      </main>

      <Footer siteName={settings.site_name} settings={settings} />
    </>
  );
}
